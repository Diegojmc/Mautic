<?php

namespace MauticPlugin\MauticBadgeGeneratorBundle;

use Mautic\PluginBundle\Bundle\PluginBundleBase;

class MauticBadgeGeneratorBundle extends PluginBundleBase
{
}
